package proxypackage;

public class employee extends user implements resources{
	
	private String name;
	private String designation;
	employee e1;
	
	public employee(String n, String d){
		name = n;
		designation=d;
	    e1= new employee(n,d);
	}
	
	
	
	

	@Override
	public boolean getnetwork() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean getdatabase() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean getapplications() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean gettostaffroom() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	user makeuser() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
