package proxypackage;

public interface resources {
	
	public boolean getnetwork();
	public boolean getdatabase();
	public boolean getapplications();
	public boolean gettostaffroom();


}
