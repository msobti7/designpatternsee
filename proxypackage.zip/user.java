package proxypackage;

public abstract class user {
	
	abstract user makeuser();{
	
	}

}
