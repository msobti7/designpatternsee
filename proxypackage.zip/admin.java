package proxypackage;

public class admin extends user {
	
	private String name;
	admin a1;

	@Override
	user makeuser() {
		// TODO Auto-generated method stub
		return null;
	}
	public  admin(String n){
		name=n;
		a1= new admin(n);
		
	}

}
